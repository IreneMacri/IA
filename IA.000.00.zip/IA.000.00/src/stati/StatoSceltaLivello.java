package stati;

import java.awt.Color;
import java.awt.Graphics;

import logica.PCIA;
import richiamafacile.Crea;
import richiamafacile.Testo;
import schermo.Menu;
import schermo.Gestore;
import schermo.ImmaginiGrafica;
import schermo.Stato;

public class StatoSceltaLivello extends Stato{

	private PCIA pcia;
	
	public StatoSceltaLivello(PCIA pcia) {
		super();
		this.pcia=pcia;
		gestore=new Gestore();
		pcia.getMouse().setGestore(gestore);
		gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(325),Crea.convertiMisuraAlt(150),Crea.convertiMisuraLargh(150),Crea.convertiMisuraAlt(60),Crea.livello,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				pcia.setNStage(1);
				pcia.getGame().statogioco=new StatoGioco(pcia);
				pcia.getGame().statogioco.setAttivo(true);
				pcia.getGame().statosceltalivello.setAttivo(false);
				Stato.setStato(pcia.getGame().statogioco);
			}
		}));
		gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(325),Crea.convertiMisuraAlt(250),Crea.convertiMisuraLargh(150),Crea.convertiMisuraAlt(60),Crea.livello,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				pcia.setNStage(2);
				pcia.getGame().statogioco=new StatoGioco(pcia);
				pcia.getGame().statogioco.setAttivo(true);
				pcia.getGame().statosceltalivello.setAttivo(false);
				Stato.setStato(pcia.getGame().statogioco);
			}
		}));
		gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(325),Crea.convertiMisuraAlt(350),Crea.convertiMisuraLargh(150),Crea.convertiMisuraAlt(60),Crea.livello,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				pcia.setNStage(3);
				pcia.getGame().statogioco=new StatoGioco(pcia);
				pcia.getGame().statogioco.setAttivo(true);
				pcia.getGame().statosceltalivello.setAttivo(false);
				Stato.setStato(pcia.getGame().statogioco);
			}
		}));
		gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(325),Crea.convertiMisuraAlt(450),Crea.convertiMisuraLargh(150),Crea.convertiMisuraAlt(60),Crea.livello,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				pcia.setNStage(4);
				pcia.getGame().statogioco=new StatoGioco(pcia);
				pcia.getGame().statogioco.setAttivo(true);
				pcia.getGame().statosceltalivello.setAttivo(false);
				Stato.setStato(pcia.getGame().statogioco);
			}
		}));
		gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(325),Crea.convertiMisuraAlt(550),Crea.convertiMisuraLargh(150),Crea.convertiMisuraAlt(60),Crea.livello,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				pcia.setNStage(5);
				pcia.getGame().statogioco=new StatoGioco(pcia);
				pcia.getGame().statogioco.setAttivo(true);
				pcia.getGame().statosceltalivello.setAttivo(false);
				Stato.setStato(pcia.getGame().statogioco);
			}
		}));
		
		gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(650),Crea.convertiMisuraAlt(620),Crea.convertiMisuraLargh(100),Crea.convertiMisuraAlt(60),Crea.back,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				pcia.getMouse().setGestore(pcia.getGame().statomenu.getGestore());
				pcia.getGame().statomenu.setAttivo(true);
				pcia.getGame().statosceltalivello.setAttivo(false);
				Stato.setStato(pcia.getGame().statomenu);
			}
		}));
		
	}
	
	@Override
	public void aggiorna() {
		if (!attivo)
			return;
		gestore.aggiorna();
	}

	@Override
	public void disegna(Graphics g) {
		g.drawImage(Crea.sfondolivello,0, 0, PCIA.getLarghezza(), PCIA.getAltezza(),null);
		gestore.disegna(g);
		Testo.drawString(g, "LIVELLO1" ,Crea.convertiMisuraLargh(400),Crea.convertiMisuraAlt(180),true,Color.WHITE,Crea.font2);
		Testo.drawString(g, "LIVELLO2" ,Crea.convertiMisuraLargh(400),Crea.convertiMisuraAlt(280),true,Color.WHITE,Crea.font2);
		Testo.drawString(g, "LIVELLO3" ,Crea.convertiMisuraLargh(400),Crea.convertiMisuraAlt(380),true,Color.WHITE,Crea.font2);
		Testo.drawString(g, "LIVELLO4" ,Crea.convertiMisuraLargh(400),Crea.convertiMisuraAlt(480),true,Color.WHITE,Crea.font2);
		Testo.drawString(g, "LIVELLO5" ,Crea.convertiMisuraLargh(400),Crea.convertiMisuraAlt(580),true,Color.WHITE,Crea.font2);
		
	}

}
