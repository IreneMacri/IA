package stati;

import java.awt.Color;
import java.awt.Graphics;

import logica.PCIA;
import richiamafacile.Crea;
import richiamafacile.Testo;
import schermo.Gestore;
import schermo.ImmaginiGrafica;
import schermo.Menu;
import schermo.Stato;


public class StatoVitScon extends Stato{

	private PCIA pcia;
	private boolean fin=false;
	protected boolean vittoria;
	private int co=3000,score;
	private long last;
	
	public StatoVitScon(PCIA pcia,boolean a) {
		super();
		this.pcia=pcia;
		vittoria=a;
		gestore=new Gestore();
		pcia.getMouse().setGestore(gestore);
		if(vittoria) {
			gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(250),Crea.convertiMisuraAlt(410),Crea.convertiMisuraLargh(100),Crea.convertiMisuraAlt(75),Crea.play,new Menu() {
				@Override
				public void click() {
					if (!attivo)
						return;
					if(pcia.getNStage()<5) {
						pcia.setNStage(pcia.getNStage()+1);
						pcia.getGame().statogioco=new StatoGioco(pcia);
						pcia.getGame().statogioco.setAttivo(true);
						pcia.getGame().statovitscon.setAttivo(false);
						pcia.getStage().setScore(score);
						Stato.setStato(pcia.getGame().statogioco);
					}else {
						fin=true;
						last=System.currentTimeMillis();
					}
				}
			}));
			
			gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(450),Crea.convertiMisuraAlt(410),Crea.convertiMisuraLargh(100),Crea.convertiMisuraAlt(75),Crea.back,new Menu() {
				@Override
				public void click() {
					if (!attivo)
						return;
					
					pcia.getMouse().setGestore(pcia.getGame().statomenu.getGestore());
					pcia.getGame().statomenu.setAttivo(true);
					pcia.getGame().statovitscon.setAttivo(false);
					Stato.setStato(pcia.getGame().statomenu);
				}
			}));
		}else {

			gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(350),Crea.convertiMisuraAlt(410),Crea.convertiMisuraLargh(100),Crea.convertiMisuraAlt(70),Crea.back,new Menu() {
				@Override
				public void click() {
					if (!attivo)
						return;
					
					pcia.getMouse().setGestore(pcia.getGame().statomenu.getGestore());
					pcia.getGame().statomenu.setAttivo(true);
					pcia.getGame().statovitscon.setAttivo(false);
					Stato.setStato(pcia.getGame().statomenu);
				}
			}));
		}
		
	}
	
	@Override
	public void aggiorna() {
		if (!attivo)
			return;
		gestore.aggiorna();
		if(fin&&(System.currentTimeMillis()-last>co)) {
			fin=false;
		}
	}

	@Override
	public void disegna(Graphics g) {
		
		g.drawImage(Crea.fondo0, 0,0,PCIA.getLarghezza(),PCIA.getAltezza(), null);
		g.drawImage(Crea.sfondo0, 0,0,PCIA.getLarghezza(),PCIA.getAltezza(), null);
		g.drawImage(Crea.sfondovittoria,(int)Crea.convertiMisuraLargh(200),(int)Crea.convertiMisuraAlt(210),(int)Crea.convertiMisuraLargh(400),(int)Crea.convertiMisuraAlt(300),null);
		if(vittoria) {
			Testo.drawString(g, "VITTORIA",Crea.convertiMisuraLargh(290), Crea.convertiMisuraAlt(250), false, Color.YELLOW, Crea.font3);
		}else {
			Testo.drawString(g, "SCONFITTA",Crea.convertiMisuraLargh(290), Crea.convertiMisuraAlt(250), false, Color.YELLOW, Crea.font3);
		}
		Testo.drawString(g, "SCORE: "+score,Crea.convertiMisuraLargh(340), Crea.convertiMisuraAlt(300), false, Color.YELLOW, Crea.font2);
		gestore.disegna(g);
		if(fin) {
			Testo.drawString(g, "STAGE FINITI",Crea.convertiMisuraLargh(275), Crea.convertiMisuraAlt(360), false, Color.RED, Crea.font3);
		}
	}

	
	
//**********************GET	
	public boolean isVittoria() {
		return vittoria;
	}

	public int getScore() {
		return score;
	}
	
	
//***********************SET	
	
	public void setVittoria(boolean vittoria) {
		this.vittoria = vittoria;
	}


	public void setScore(int score) {
		this.score = score;
	}

	
}
