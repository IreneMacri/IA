package stati;

import java.awt.Graphics;

import logica.PCIA;
import logica.Stage;
import richiamafacile.Crea;
import schermo.Stato;


public class StatoGioco extends Stato{

	private Stage stage;
	
	public StatoGioco(PCIA pcia) {
		super();
		if(pcia.getNStage()==1) {
			stage= new Stage(pcia,"/file/stage1.txt");
		}
		if(pcia.getNStage()==2) {
			stage= new Stage(pcia,"/file/stage2.txt");
		}
		if(pcia.getNStage()==3) {
			stage= new Stage(pcia,"/file/stage3.txt");
		}
		if(pcia.getNStage()==4) {
			stage= new Stage(pcia,"/file/stage4.txt");
		}
		if(pcia.getNStage()==5) {
			stage= new Stage(pcia,"/file/stage5.txt");
		}
			pcia.setStage(stage);
	}
	
	@Override
	public void aggiorna() {
		if (!attivo)
			return;
		stage.aggiorna();
	}

	@Override
	public void disegna(Graphics g) {
		stage.disegna(g);
		
	}

}
