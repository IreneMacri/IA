package stati;

import java.awt.Graphics;
import java.awt.Image;

import logica.PCIA;
import richiamafacile.Crea;
import schermo.Menu;
import schermo.Gestore;
import schermo.ImmaginiGrafica;
import schermo.Stato;

public class StatoMenu extends Stato{

	private PCIA pcia;
	
	public StatoMenu(PCIA pcia) {
		super();
		this.pcia=pcia;
		gestore=new Gestore();
		pcia.getMouse().setGestore(gestore);
		gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(320),Crea.convertiMisuraAlt(380),Crea.convertiMisuraLargh(128),Crea.convertiMisuraAlt(100),Crea.play,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				pcia.setNStage(1);
				pcia.getGame().statogioco=new StatoGioco(pcia);
				pcia.getGame().statogioco.setAttivo(true);
				pcia.getGame().statomenu.setAttivo(false);
				Stato.setStato(pcia.getGame().statogioco);

			}
		}));		
		
		gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(150),Crea.convertiMisuraAlt(630),Crea.convertiMisuraLargh(120),Crea.convertiMisuraAlt(42),Crea.scelta,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				pcia.getGame().statosceltalivello=new StatoSceltaLivello(pcia);
				pcia.getGame().statosceltalivello.setAttivo(true);
				pcia.getGame().statomenu.setAttivo(false);
				Stato.setStato(pcia.getGame().statosceltalivello);
			}
		}));
	
		gestore.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(635),Crea.convertiMisuraAlt(630),Crea.convertiMisuraLargh(85),Crea.convertiMisuraAlt(65),Crea.exit,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				System.exit(0);
			}
		}));
	}
	


	@Override
	public void aggiorna() {
		if (!attivo)
			return;
		gestore.aggiorna();
	}

	@Override
	public void disegna(Graphics g) {
		g.drawImage(Crea.sfondomenu, 0,0,PCIA.getLarghezza(),PCIA.getAltezza(), null);
		gestore.disegna(g);
		
	}

	
	
}