package schermo;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

public abstract class OggettiGrafica {
	protected float x,y;
	protected float altezza,larghezza;
	protected boolean sopra=false;
	protected Rectangle bordi;
	protected boolean selezionato=false;
	
	public OggettiGrafica(float x,float y,float larghezza, float altezza) {
		this.x=x;
		this.y=y;
		this.altezza=altezza;
		this.larghezza=larghezza;	
		bordi=new Rectangle((int)x,(int)y,(int)larghezza,(int)altezza);
	}

	public abstract void aggiorna();
	
	public abstract void disegna(Graphics g);
	
	public abstract void click();
	
	public void sottoMouse(MouseEvent e) {
		if(bordi.contains(e.getX(),e.getY())) {
			sopra=true;
		}else {
			sopra=false;
		}
	}
	
	public void lasciaMouse(MouseEvent e) {
		if(sopra) {
			click();
		}
	}
	
	public abstract void trascina(MouseEvent e);
	
//*************************GET********************	
	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public float getAltezza() {
		return altezza;
	}

	public float getLarghezza() {
		return larghezza;
	}

	public boolean isSopra() {
		return sopra;
	}

	public boolean getSelezionato() {
		return selezionato;
	}
	
//********************************SET***********************************	
	public void setSelezionato(boolean a) {
		selezionato=a;
	}
	
	
	public void setSopra(boolean sopra) {
		this.sopra = sopra;
	}
	
	public void setLarghezza(int larghezza) {
		this.larghezza = larghezza;
	}


	public void setAltezza(int altezza) {
		this.altezza = altezza;
	}

	public void setX(float x) {
		this.x = x;
	}

	public void setY(float y) {
		this.y = y;
	}


}
