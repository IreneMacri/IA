package schermo;

public interface Menu {
		
	public void click();
}
