package schermo;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;


public class Mouse implements MouseListener,MouseMotionListener{

	private static int x;
	private static int y;
	private static boolean destro=false;
	private static boolean sinistro=false;
	private Gestore gestore;
	
	public Mouse() {
		
	}
	
	

	
	@Override
	public void mouseDragged(MouseEvent e) {
		if(gestore!=null) {
			gestore.trascina(e);
	}
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		x=e.getX();
		y=e.getY();
		if(gestore!=null) {
			gestore.sottoMouse(e);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public boolean ClickDes(MouseEvent e) {
		if(e.getButton()==MouseEvent.BUTTON3){
			return true;
		}
		return false;
	}	
	
	
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if(e.getButton()==MouseEvent.BUTTON1){
			sinistro=true;
		} 
		if(e.getButton()==MouseEvent.BUTTON3){
			destro=true;
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if(e.getButton()==MouseEvent.BUTTON1){
			sinistro=false;
		}else if(e.getButton()==MouseEvent.BUTTON3){
			destro=false;
		}
		if(gestore!=null) {
			gestore.lasciaMouse(e);
		}
	}

	
//******************************GET****************************
	public boolean tastoDestro() {
		return destro;
	}
	
	public boolean tastoSinistro() {
		return sinistro;
	}

	public static int getX() {
		return x;
	}

	public static int getY() {
		return y;
	}
	
	

	public static boolean isDestro() {
		return destro;
	}




	public static boolean isSinistro() {
		return sinistro;
	}




	//*****************************SET*******************************************
	public void setGestore(Gestore gestore) {
		this.gestore=gestore;
	}
	
}
