package schermo;

import java.awt.Graphics;

import logica.PCIA;


public abstract class Stato {
	
	private static Stato stato=null;
	protected boolean attivo=false;
	protected Gestore gestore;
	protected PCIA pcia;
	
	public Stato() {
	}
	
	
	public static void setStato(Stato s) {
		stato=s;
	}
	
	public static Stato getStato() {
		return stato;
	}
	
	public abstract void aggiorna();
	
	public abstract void disegna(Graphics g);
	
	public boolean isAttivo() {
		return attivo;
	}
	
	public void setAttivo(boolean attivo) {
		this.attivo=attivo;
	}
	
	public Gestore getGestore() {
		return gestore;
	}
}
