package schermo;

import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
 
public class ImmaginiGrafica extends OggettiGrafica {
	
	private BufferedImage[] img;
	private Menu menu=null;
	

	public ImmaginiGrafica(float x, float y, float larghezza, float altezza, BufferedImage[] img, Menu menu2) {
		super(x, y, larghezza, altezza);
		this.img=img;
		this.menu=menu2;
	}


	@Override
	public void aggiorna() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disegna(Graphics g) {
		if(sopra){
			g.drawImage(img[1], (int)x, (int)y,(int)larghezza,(int)altezza,null);
		}else {
			g.drawImage(img[0], (int)x, (int)y,(int)larghezza,(int)altezza,null);
		}
	}

	@Override
	public void click() {
			menu.click();
		
	}

	@Override
	public void trascina(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


//********************************SET*******************************
	
	
//***********************GET*********************************	
	
	
}
