package schermo;

import java.awt.image.BufferedImage;

public class Anima {
	private int velocita,id;
	private long ltime,timer;
	private BufferedImage[] img;
	
	public Anima(int velocita, BufferedImage[] img) {
		this.velocita=velocita;
		this.img=img;
		id=0;
		timer=0;
		ltime=System.currentTimeMillis();
		
	}

	public void aggiorna() {
		timer+=System.currentTimeMillis()-ltime;
		ltime=System.currentTimeMillis();
		if(timer>velocita){
			id++;
			timer=0;
			if(id>=img.length) {
				id=0;
			}
		}
	}
	
//***************GET**************
	public BufferedImage getImg() {
		return img[id];
	}
	
	
	public BufferedImage getSinImg(int a) {
		return img[a];
	}
}
