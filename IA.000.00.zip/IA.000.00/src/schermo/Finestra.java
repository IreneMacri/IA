package schermo;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class Finestra {
	
	private JFrame schermo;
	private Canvas disegno;
	private String nome;
	private int larghezza,altezza;
	

	public Finestra(String n,int l, int a) {
		this.nome=n;
		this.larghezza=l;
		this.altezza=a;
		accendiDisplay();
	}

	public void accendiDisplay() {
		schermo=new JFrame(nome);
		//dimensioniSchermo();//******************************* PER IL FULL SCREEN
		schermo.setUndecorated(true);
		schermo.setSize(larghezza,altezza);
		schermo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		schermo.setResizable(false);
		schermo.setLocationRelativeTo(null);
		schermo.setVisible(true);
		disegno=new Canvas();
		disegno.setPreferredSize(new Dimension(larghezza,altezza));
		disegno.setMaximumSize(new Dimension(larghezza,altezza));
		disegno.setMinimumSize(new Dimension(larghezza,altezza));
		disegno.setBackground(Color.black);
		disegno.setFocusable(false);
		schermo.add(disegno);
		schermo.pack();
	}
	
	
		public void dimensioniSchermo()
		{
			Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
			larghezza=(int) screensize.getWidth();
			altezza=(int) screensize.getHeight();
		}
	
	public Canvas getDisegno() {
		return disegno;
	}
	
	public JFrame getSchermo() {
		return schermo;
	}
	
	public int getLarghezza() {
		return schermo.getContentPane().getWidth();
	}

	public int getAltezza() {
		return schermo.getContentPane().getHeight();
	}	
}
