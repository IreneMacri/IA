package schermo;

import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.util.ArrayList;



public class Gestore {

	private ArrayList<OggettiGrafica>oggetti;
	
	public Gestore() {
		oggetti=new ArrayList<OggettiGrafica>();
	}
	
	public void aggiorna() {
		for(OggettiGrafica og: oggetti)
			og.aggiorna();
	}
	
	public void disegna(Graphics g) {
		for(OggettiGrafica og: oggetti)
			og.disegna(g);
	}
	
	public void sottoMouse(MouseEvent e) {
		for(OggettiGrafica og: oggetti)
			og.sottoMouse(e);
	}
	
	public void lasciaMouse(MouseEvent e) {
		for(OggettiGrafica og: oggetti)
			og.lasciaMouse(e);	
	}
	
	public OggettiGrafica getOggetto(int a) {
		return oggetti.get(a);
	}
	
	public void aggiungiOggetto(OggettiGrafica og) {
		oggetti.add(og);
	}
	
	public void rimuoviOggetto(OggettiGrafica og) {
		oggetti.remove(og);
	}

	public void trascina(MouseEvent e) {
		for(OggettiGrafica og: oggetti)
			og.trascina(e);	
	}
}
