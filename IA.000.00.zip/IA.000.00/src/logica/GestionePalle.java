package logica;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import richiamafacile.Crea;
import schermo.Anima;

public class GestionePalle{


	private GestionePercorso ges;
	protected ArrayList<Palla> palle;
	protected boolean aspetta,modifiche=false;;
	private int a,posizionecol,cont,cop=0,mod;
	private Anima ready;
	private long now;
	private long last;	
	
		
	public GestionePalle(GestionePercorso ges,int a) {
	
		this.ges=ges;
		aspetta=false;
		mod=0;
		this.a=a;
		palle=new ArrayList<Palla>();
		caricaPalle();
		palle.get(0).setAttivo(true);
		ready=new Anima(500,Crea.contoallarovescia);
		last=System.currentTimeMillis();
		provaVeloce();
		
	}
	
	private void provaVeloce() {

		int co,prei,prej;
		Palla pro=new Palla(ges.getInx(),ges.getIny(),0,0,0);
		prei=ges.getInx();
		prej=ges.getIny();
		pro.setAttivo(true);
		co=0;
		while(((int)pro.getY()!=ges.getFiny())||((int)pro.getX()!=ges.getFinx())) {
			trovaDirezione(pro);
			pro.aggiorna();
			if(((int)pro.getX()!=prei)||((int)pro.getY()!=prej)) {
				prei=(int)pro.getX();
				prej=(int)pro.getY();
				co++;
				ges.setValoreP(co, (int)pro.getX(),(int)pro.getY());			
			}
			
		}
		
	}

	public void aggiorna() {
		
		ready.aggiorna();
		trovaDirezione();
		Iterator<Palla> it=palle.iterator();
		while(it.hasNext()) {
			Palla p=it.next();
			if(p.isAttivo()) {
				p.aggiorna();
			}
			if(p.isPausa()) {
				mod+=1;
				contatto();
			}
		}
		if (mod!=0) {
			aspetta=true;
			mod=0;
		}else {
			aspetta=false;
		}
		
	}

	private void caricaPalle() {
		
		for(int i=0;i<a;i++) {
			Random col=new Random();
			int a=col.nextInt(6)+0;
			palle.add(new Palla(ges.getInx(),ges.getIny(),a,0,i));
		}
		trovaDirezione();
		
	}


	private void trovaDirezione(Palla p) {

		if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==1) {
			if(ges.getCasella((int)(p.getX()+1),(int)(p.getY()))!=0) {
				p.setDirezione(1);
			}else if(ges.getCasella((int)(p.getX()),(int)(p.getY()+1))!=0) {
				p.setDirezione(2);
			}else if(ges.getCasella((int)(p.getX()-1),(int)(p.getY()))!=0) {
				p.setDirezione(3);
			}else if(ges.getCasella((int)(p.getX()),(int)(p.getY()-1))!=0) {
				p.setDirezione(4);
			}	
		}		
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==7) {
					p.setAttivo(false);
				}
			
			if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==3&&p.getDirezione()==1) {
				if(p.getX0()>=((int)(p.getX())*ges.getLa()+(ges.getLa()/2)-p.getLarghezza()/2)) {
					p.setDirezione(2);
				}
			}
			if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==3&&p.getDirezione()==4) {
				if(p.getY0()<=((int)(p.getY())*ges.getAl()+Crea.convertiMisuraAlt(48)+ges.getAl()/2-p.getAltezza()/2)) {
					p.setDirezione(3);
				}
			}
			if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==6&&p.getDirezione()==1) {
				if(p.getX0()>=(int)(p.getX())*ges.getLa()+ges.getLa()/2-p.getLarghezza()/2) {
					p.setDirezione(4);
				}
			}
			if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==6&&p.getDirezione()==2) {
				if(p.getY0()>=(int)(p.getY())*ges.getAl()+Crea.convertiMisuraAlt(48)+ges.getAl()/2-p.getAltezza()/2) {
					p.setDirezione(3);
				}
			}
			if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==4&&p.getDirezione()==2) {
				if(p.getY0()>=(int)(p.getY())*ges.getAl()+Crea.convertiMisuraAlt(48)+ges.getAl()/2-p.getAltezza()/2) {
					p.setDirezione(1);
				}
			}
			if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==5&&p.getDirezione()==3) {
				if(p.getX0()<=(int)(p.getX())*ges.getLa()+ges.getLa()/2-p.getLarghezza()/2) {
					p.setDirezione(2);
				}
			}
			if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==5&&p.getDirezione()==4) {
				if(p.getY0()<=(int)(p.getY())*ges.getAl()+Crea.convertiMisuraAlt(48)+ges.getAl()/2-p.getAltezza()/2) {
					p.setDirezione(1);
				}
			}
			if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==4&&p.getDirezione()==3) {
				if(p.getX0()<=(int)(p.getX())*ges.getLa()+ges.getLa()/2-p.getLarghezza()/2) {
					p.setDirezione(4);
				}
			}
			
		}
	
	
	private void trovaDirezione() {
		
		Iterator<Palla> it=palle.iterator();
		while(it.hasNext()) {
			Palla p=it.next();
			if(p.isAttivo()) {	
			if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==1) {
				if(ges.getCasella((int)(p.getX()+1),(int)(p.getY()))!=0) {
					p.setDirezione(1);
				}else if(ges.getCasella((int)(p.getX()),(int)(p.getY()+1))!=0) {
					p.setDirezione(2);
				}else if(ges.getCasella((int)(p.getX()-1),(int)(p.getY()))!=0) {
					p.setDirezione(3);
				}else if(ges.getCasella((int)(p.getX()),(int)(p.getY()-1))!=0) {
					p.setDirezione(4);
					}	
				}		
			if(cop<palle.size()&&p.getValore()==cop) {
				if(p.getDirezione()==1) {
					if(p.getX0()-ges.getCeInX()>=p.getLarghezza()/2) {
						cop++;
					}
				}else if(p.getDirezione()==4) {
					if(Math.abs(p.getY0()-ges.getCeInY())>=(int)(p.getAltezza()/2+p.getAltezza())) {
						cop++;
					}
				}else if(p.getDirezione()==2) {
					if(p.getY0()-ges.getCeInY()>=(int)(p.getAltezza()/2)) {
						cop++;
					}
				}else if(p.getDirezione()==3) {
					if(ges.getCeInX()-p.getX0()>(p.getLarghezza()+p.getLarghezza()/2)) {
						cop++;
					}
				}
			}	
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==7) {
					p.setAttivo(false);
				}
				
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==3&&p.getDirezione()==1) {
					if(p.getX0()>=((int)(p.getX())*ges.getLa()+(ges.getLa()/2)-p.getLarghezza()/2)) {
						p.setDirezione(2);
					}
				}
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==3&&p.getDirezione()==4) {
					if(p.getY0()<=((int)(p.getY())*ges.getAl()+Crea.convertiMisuraAlt(48)+ges.getAl()/2-p.getAltezza()/2)) {
						p.setDirezione(3);
					}
				}
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==6&&p.getDirezione()==1) {
					if(p.getX0()>=(int)(p.getX())*ges.getLa()+ges.getLa()/2-p.getLarghezza()/2) {
						p.setDirezione(4);
					}
				}
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==6&&p.getDirezione()==2) {
					if(p.getY0()>=(int)(p.getY())*ges.getAl()+Crea.convertiMisuraAlt(48)+ges.getAl()/2-p.getAltezza()/2) {
						p.setDirezione(3);
					}
				}
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==4&&p.getDirezione()==2) {
					if(p.getY0()>=(int)(p.getY())*ges.getAl()+Crea.convertiMisuraAlt(48)+ges.getAl()/2-p.getAltezza()/2) {
						p.setDirezione(1);
					}
				}
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==5&&p.getDirezione()==3) {
					if(p.getX0()<=(int)(p.getX())*ges.getLa()+ges.getLa()/2-p.getLarghezza()/2) {
						p.setDirezione(2);
					}
				}
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==5&&p.getDirezione()==4) {
					if(p.getY0()<=(int)(p.getY())*ges.getAl()+Crea.convertiMisuraAlt(48)+ges.getAl()/2-p.getAltezza()/2) {
						p.setDirezione(1);
					}
				}
				if(ges.getCasella((int)(p.getX()),(int)(p.getY()))==4&&p.getDirezione()==3) {
					if(p.getX0()<=(int)(p.getX())*ges.getLa()+ges.getLa()/2-p.getLarghezza()/2) {
						p.setDirezione(4);
					}
				}
			} 
			else {
				if(p.getValore()==cop) {
					p.setAttivo(true);
				}
			
			}	
		}
		
	}


	
	
	public void disegnaDown(Graphics g) {

		now=System.currentTimeMillis();
		if((now-last>0)&&(now-last<4000)) {
			g.drawImage(ready.getImg(), (int)(Crea.convertiMisuraLargh(Vivi.larghezza/2-80)), (int)((Crea.convertiMisuraAlt(Vivi.altezza/2)-50)),null) ;
		}
	
	}
		
	
	public void disegna(Graphics g) {

		for(int i=0;i<palle.size();i++) {
			if(palle.get(i).isAttivo()) {
				palle.get(i).disegna(g);
			}	
		}
		
	}
	
	public boolean parti() {
		
		now=System.currentTimeMillis();
		return (now-last>0)&&(now-last<4000);
		
	}
	
	public boolean interseca(Palla x) {
		
		Iterator<Palla> it=palle.iterator();
		while(it.hasNext()) {
			Palla p=it.next();
			if(p.tiHoPreso(x.getCentroX(),x.getCentroY())) {
				return true;
			}
		}
		return false;
		
	}
	
	
	public int getPosizioneColpita(Palla x) {
		
		Iterator<Palla> it=palle.iterator();
		while(it.hasNext()) {
			Palla p=it.next();
			if(p.tiHoPreso(x.getCentroX(),x.getCentroY())) {
				return p.getValore();
			}
		}
		return -1;
		
	}
	
	
	private void contatto() {

		if(posizionecol<palle.size()-1&&palle.size()>1) {
			if(modifiche) {
				if(Math.abs(palle.get(posizionecol).getCentroX()-palle.get(posizionecol+1).getCentroX())>=palle.get(0).getLarghezza()||
						Math.abs(palle.get(posizionecol).getCentroY()-palle.get(posizionecol+1).getCentroY())>=palle.get(0).getAltezza()) {
					modifiche=false;
					riattiva();
				}
			}else {
					if(Math.abs(palle.get(posizionecol).getCentroX()-palle.get(posizionecol+1).getCentroX())==palle.get(0).getLarghezza()||
							Math.abs(palle.get(posizionecol).getCentroY()-palle.get(posizionecol+1).getCentroY())==palle.get(0).getAltezza()) {
						riattiva();
					}
			}
		}else {
			riattiva();
		}
	}

	
	public void aggiungiPalla(Palla x,int aa) {
		
		modifiche=true;
		posizionecol=aa;
		x.setDirezione(palle.get(aa).getDirezione());
		x.setX0(palle.get(aa).getX0());
		x.setY0(palle.get(aa).getY0());
		x.setAttivo(true);
		if (aa+1>=palle.size())
			palle.add(x);
		else
			palle.add(aa+1, x);
		for(int i=0;i<palle.size();i++) {
			palle.get(i).setValore(i);
			if(i>aa) {	
				palle.get(i).setPausa(true);
			}		
		}
	}
	


	public boolean isModifiche() {
		
		return modifiche;
		
	}	
	
	
	public void controlloTris(int a,int col) {
		
		cont=1;
		int i=0,j=0;
		if(palle.get(a).getColore()!=col) {
			i=1;
			while(a+i<palle.size()&&palle.get(i+a).getColore()==col) {
				cont++;
				i++;
			}
		}else {
			i=1;
			cont++;
			while(a+i<palle.size()&&palle.get(i+a).getColore()==col) {
				cont++;
				i++;
			}
			j=1;
			while(a-j>=0&&palle.get(a-j).getColore()==col) {
				cont++;
				j++;
			}
		}	
		if(cont>2) {
			for(int h=0;h<cont-1;h++) {
				palle.remove(a-j+1);
			}
			for(int h=0;h<palle.size();h++) {
				palle.get(h).setValore(h);
			}
			
			for(int h=0;h<a-j+1;h++) {
				palle.get(h).setPausa(true);;
			}
			posizionecol=a-j;
		}		
		
	}
	
	public void riattiva() {
		
		for(int h=0;h<palle.size();h++) {
			palle.get(h).setPausa(false);
		}
		
				
		
	}
	
	public Palla cercaPalla(int valore ) {

		for(int h=0;h<palle.size();h++) {
			if(palle.get(h).getValore()==valore) {
				return palle.get(h);
			}
		}
		return null;
		
	}
	
//************************************GET***************************
	public Palla getPrimaPalla() {
		
		if(palle.size()>0)
			return palle.get(0);
		return null;
		
	}

	public ArrayList<Palla> getPalle(){
		return palle;
	}
	
	
	public int getColoreX(int a) {
		
		return palle.get(a).getColore();
	}
	
	public Palla getPallaX(int a) {
		
		return palle.get(a);
	}

	public GestionePercorso getGes() {
		
		return ges;
		
	}

	public boolean finito() {
		
		return palle.size()==0;
		
	}

	public int getPosizionecol() {
		return posizionecol;
	}


	public int getCont() {
		return cont;
	}

	public boolean colorePresente(int c) {
		for(int i=0;i<palle.size();i++) {
			if(palle.get(i).getColore()==c) {
				return true;
			}
		}
			return false;
	}

	
	public boolean isAspetta() {
		return aspetta;
	}
	
	
//****************************************************SET
	

	public void setCont(int cont) {
		this.cont = cont;
	}
	

	public void setPosizionecol(int posizionecol) {
		this.posizionecol = posizionecol;
	}

	
	
	
	
	
	
}	