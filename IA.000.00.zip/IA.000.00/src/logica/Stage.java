  package logica;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import logica.GestisciOggetti;
import richiamafacile.Crea;
import richiamafacile.Testo;
import schermo.Gestore;
import schermo.ImmaginiGrafica;
import schermo.Menu;
import schermo.Stato;
import stati.StatoMenu;
import stati.StatoVitScon;


public class Stage {

	private boolean attivo;
	private PCIA pcia;
	private GestisciOggetti gestore;
	private Gestore gestoreg;
	private BufferedImage sfondo,fondo;
	private long now=0,last=0;
	protected int score=0;

	
	

	
	
	public Stage(PCIA pcia,String pos) {
		this.sfondo=Crea.sfondo0;
		this.fondo=Crea.fondo0;
		this.pcia=pcia;
		attivo=true;
		gestore=new GestisciOggetti(pos,(2+1*pcia.getNStage()),pcia);
		gestoreg=new Gestore();
		pcia.getMouse().setGestore(gestoreg);
		gestoreg.aggiungiOggetto(new ImmaginiGrafica(Crea.convertiMisuraLargh(680),Crea.convertiMisuraAlt(5),Crea.convertiMisuraLargh(80),Crea.convertiMisuraAlt(32),Crea.bottonemenu,new Menu() {
			@Override
			public void click() {
				if (!attivo)
					return;
				attivo=false;
				pcia.getGame().statomenu=new StatoMenu(pcia);
				pcia.getGame().statomenu.setAttivo(true);
				pcia.getGame().statogioco.setAttivo(false);
				Stato.setStato(pcia.getGame().statomenu);
			}
		}));
		

	}

	public void aggiorna() {
		
			gestoreg.aggiorna();
			gestore.aggiorna();
			score=gestore.getScore();
			if(gestore.isModifica()) {
				gestore.setModifica(false);
				last=System.currentTimeMillis();
			}
			if(gestore.isVinto()){
				pcia.getGame().statovitscon=new StatoVitScon(pcia,true);
				pcia.getGame().statovitscon.setScore(gestore.getScore());
				pcia.getGame().statovitscon.setAttivo(true);
				pcia.getGame().statogioco.setAttivo(false);
				Stato.setStato(pcia.getGame().statovitscon);
			}
			if(gestore.isPerso()){
				pcia.getGame().statovitscon=new StatoVitScon(pcia,false);
				pcia.getGame().statovitscon.setScore(gestore.getScore());
				pcia.getGame().statovitscon.setAttivo(true);
				pcia.getGame().statogioco.setAttivo(false);
				Stato.setStato(pcia.getGame().statovitscon);
			}
		
	}
	
	
	
	
	public void disegna (Graphics g) {
		
			g.drawImage(fondo, 0,0,PCIA.getLarghezza(),PCIA.getAltezza(), null);
			gestore.disegna(g);
			g.drawImage(sfondo, 0,0,PCIA.getLarghezza(),PCIA.getAltezza(), null);
			gestoreg.disegna(g);
			Testo.drawString(g,Integer.toString(score),Crea.convertiMisuraLargh(160), Crea.convertiMisuraAlt(35), false, Color.YELLOW, Crea.font2);
			now=System.currentTimeMillis();
			if((now-last<2000)&&last!=0) {				
				if(gestore.getCont()>5) {
					Testo.drawString(g, "BENE!",Crea.convertiMisuraLargh(300), Crea.convertiMisuraAlt(25), false, Color.YELLOW, Crea.font2);
				}else if(gestore.getCont()==4){
					Testo.drawString(g, "BRAVO!",Crea.convertiMisuraLargh(300), Crea.convertiMisuraAlt(25), false, Color.YELLOW, Crea.font2);
				}else if(gestore.getCont()==3) {
					Testo.drawString(g, "OTTIMO!",Crea.convertiMisuraLargh(300), Crea.convertiMisuraAlt(25), false, Color.YELLOW, Crea.font2);
				}
			}else {
				last=0;
			}
			Testo.drawString(g, "Stage"+pcia.getNStage(),Crea.convertiMisuraLargh(520), Crea.convertiMisuraAlt(35), false, Color.YELLOW, Crea.font2);
	}
	
	

	public void upScore(int i) {
		
		score+=i;
		
	}

//********************GET***************************************

	
	public PCIA getPcia() {
	
		return pcia;
	
	}
	
	
	public GestisciOggetti getGestore() {
		
		return gestore;
		
	}


	public int getScore() {
		return score;
	}

	//*******************************SET********************************

	public void setPCIA(PCIA pcia) {
		this.pcia = pcia;
	}


	public void setScore(int score) {
		this.score = score;
	}

	
}
