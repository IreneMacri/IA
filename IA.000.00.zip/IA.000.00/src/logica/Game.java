package logica;

import java.awt.Graphics;
import java.awt.image.BufferStrategy;

import richiamafacile.Crea;
import schermo.Finestra;
import schermo.Mouse;
import schermo.Stato;
import stati.StatoGioco;
import stati.StatoMenu;
import stati.StatoSceltaLivello;
import stati.StatoVitScon;



public class Game implements Runnable{

	private Finestra schermo;
	private Thread processo;
	private int larghezza,altezza;
	public String nome;
	private boolean attivo=false;
	private BufferStrategy bust;
	private Graphics g;
	
	public StatoGioco statogioco;
	public StatoMenu statomenu;
	public StatoSceltaLivello statosceltalivello;
	public StatoVitScon statovitscon;
	
	private Mouse mouse;
	private PCIA pcia;
	
	public Game(String n,int l,int a) {
		larghezza=l;
		altezza=a;
		this.nome=n;
		mouse=new Mouse();
	}
	
	
	
	private void inizializza() {
		schermo=new Finestra(nome,larghezza,altezza);
		larghezza=schermo.getLarghezza();
		altezza=schermo.getAltezza();
		schermo.getSchermo().addMouseListener(mouse);
		schermo.getSchermo().addMouseMotionListener(mouse);
		schermo.getDisegno().addMouseListener(mouse);
		schermo.getDisegno().addMouseMotionListener(mouse);
		Crea.inizializza();
		pcia=new PCIA(this);	
		statomenu=new StatoMenu(pcia);
		schermo.getDisegno().setBackground(null);
		statomenu.setAttivo(true);
		Stato.setStato(statomenu);
		

	}

	
	
	private void aggiorna() {
		
		if(Stato.getStato()!=null) {
			Stato.getStato().aggiorna();
		}
	}
	
	public void run() {
		inizializza();
		int fps=60;
		double tempoperaggiornamento=1000000000/fps;
		double delta=0;
		long now;
		long last=System.nanoTime();
		long timer=0;
		while(attivo) {
			now =System.nanoTime();
			delta+=(now-last)/tempoperaggiornamento;
			timer+=now-last;
			last=now;
			if(delta>=1) {
				aggiorna();
				disegna();
				delta--;
			}
			if(timer>=1000000000) {
				//mantiene 60 fps al secondo
				timer=0;
			}
		}
		stop();
	}
	
	public synchronized void start() {
		if(attivo) {
			return;
		}
		attivo=true;
		processo=new Thread(this);
		processo.start();
		
	}
	

	public synchronized void stop() {
		if(attivo) {
			return;
		}
		attivo=false;
		try {
			processo.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}	
	}
		
	private void disegna() {
		bust=schermo.getDisegno().getBufferStrategy();
		if (bust==null){
			schermo.getDisegno().createBufferStrategy(2);
			return;
		}
		g=bust.getDrawGraphics();
		g.clearRect(0,0,larghezza,altezza);
		
		
		if(Stato.getStato()!=null) {
			Stato.getStato().disegna(g);
		}	
		bust.show();
		g.dispose();
	}
	

//**************GET*********************	
	public int getLarghezza() {
		return schermo.getLarghezza();
	}
	
	public int getAltezza() {
		return schermo.getAltezza();
	}
	
	public Mouse getMouse() {
		return mouse;
	}



	public StatoGioco getStatogioco() {
		return statogioco;
	}

	public StatoSceltaLivello getStatosceltalivello() {
		return statosceltalivello;
	}


	public StatoMenu getStatomenu() {
		return statomenu;
	}

}

