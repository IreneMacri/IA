package logica;

import it.unical.mat.embasp.languages.Id;
import it.unical.mat.embasp.languages.Param;

@Id("spara")
public class Spara {

	@Param(0)
	protected int x0;
	@Param(1)
	protected int y0;
	
	public Spara() {
		//super(); 
	}
	public void setX(int x) {
		this.x0 = x; 
	}
	public void setY(int y) {
		this.y0 = y; 
	}
	public int getX() {
		return x0; 
	}
	public int getY() {
		return y0; 
	}
	
}
