package logica;

import java.awt.Graphics;
import java.awt.Rectangle;

import richiamafacile.Crea;

public abstract class Oggetti {
	
	protected float x,y;
	protected float larghezza;
	protected float altezza;
	protected Rectangle bordi;
	protected int vita;
	protected boolean attivo=true;
	
	public Oggetti() {
		
	}
	public Oggetti(float x,float y,float l, float a) {
		this.x=x;
		this.y=y;		
		this.larghezza=Crea.convertiMisuraLargh(l);
		this.altezza=Crea.convertiMisuraLargh(a);	
		bordi= new Rectangle(0,0,(int)larghezza,(int)altezza);
	}

	public abstract void aggiorna();
	
	public abstract void disegna(Graphics g);
	
	public abstract void muori();
	
	
	public Rectangle rettangoloCollisione(float xp,float yp) {
		return new Rectangle((int)(x+bordi.x+xp),(int)(y+bordi.y+yp),bordi.width,bordi.height);
	}

	
	
	
//*****************SET*****************	
	public void setX(float x) {
		this.x = x;
	}

	public void setY(float y) {
		this.y = y;
	}
	
	public void setLarghezza(int larghezza) {
		this.larghezza = larghezza;
	}

	public void setAltezza(int altezza) {
		this.altezza = altezza;
	}

	public void setVita(int vita) {
		this.vita = vita;
	}

	public void setAttivo(boolean attivo) {
		this.attivo = attivo;
	}

	
//********************GET****************	
	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public float getLarghezza() {
		return larghezza;
	}

	public float getAltezza() {
		return altezza;
	}

	public int getVita() {
		return vita;
	}

	public boolean isAttivo() {
		return attivo;
	}
	

}
