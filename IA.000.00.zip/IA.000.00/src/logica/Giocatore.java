package logica;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Random;

import disegnafacile.Pezzo;
import richiamafacile.Crea;
import schermo.Mouse;

public class Giocatore extends Oggetti{
	
	private BufferedImage [] img;
	private float x1,y1,x0,y0;
	private PCIA pcia;
	private int wait=0;
	private double radianti;
	private boolean sparato;
	float pallax,pallay,xPi,yPi;
	protected ArrayList<Palla> palle;
	private long now,last,ianow,ialast;	
	public IA ia; 
	protected boolean colpito=false;
		
	
	public Giocatore(float x, float y,BufferedImage [] img,PCIA pcia) {
		
		super(x, y, 64,64);	
		this.pcia=pcia;
		ia = new IA(); 
		x1=(x*Crea.convertiMisuraLargh(Pezzo.larghezza_default));
		y1=(y*Crea.convertiMisuraAlt(Pezzo.altezza_default))-altezza/2+Crea.convertiMisuraAlt(48);
		x0=(x*Crea.convertiMisuraLargh(Pezzo.larghezza_default));
		y0=(y*Crea.convertiMisuraAlt(Pezzo.altezza_default))+Crea.convertiMisuraAlt(48);
		this.img=img;
		sparato=false;
		palle=new ArrayList<Palla>();
		Random col=new Random();
		int a=col.nextInt(6)+0;
		while(!pcia.getGesogg().gestionepalle.colorePresente(a) ){
			col=new Random();
			a=col.nextInt(6)+0;
		}

		palle.add(new Palla(x,y,a,0,-1));
		col=new Random();
		a=col.nextInt(6)+0;
		while(!pcia.getGesogg().gestionepalle.colorePresente(a) ){
			col=new Random();
			a=col.nextInt(6)+0;
		}
		palle.add(new Palla(x,y,a,0,-1));
		
		palle.get(0).setY0((int) (y0-Crea.convertiMisuraAlt(12)));
		palle.get(0).setX0((int) (x0-Crea.convertiMisuraLargh(12)));
		xPi = palle.get(0).getX0();
        yPi = palle.get(0).getY0(); 
        ialast=System.currentTimeMillis();
	}

	
	@Override
	public void aggiorna() {
		
		ianow=System.currentTimeMillis();
        if(colpito) {
			nuovoProiettile();
        	this.sparato = false;
        	this.colpito= false;
        }
        if(!sparato && !colpito) {
        	if (!(ianow-ialast<1700||(pcia.getGesogg().gestionepalle.isAspetta()))){
        		ialast=System.currentTimeMillis();
	        	sparato=true;
	        	int s1=(int)(pcia.getGesogg().gestionepalle.getPrimaPalla().getAltezza()/10);
				int s2=(int)(pcia.getGesogg().gestionepalle.getPrimaPalla().getLarghezza()/10);
				int[] res = new int [3];
				
				try {
					res = ia.executeDLV(pcia.getGesogg().gestionepalle.getPalle(),getProiettile(),(int) pcia.getGesogg().gestionepalle.getPrimaPalla().getAltezza(),s1,(int)pcia.getGesogg().gestionepalle.getPrimaPalla().getLarghezza(),s2,(int)Crea.convertiMisuraLargh(24),(int)Crea.convertiMisuraAlt(24));
					
					
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
						| NoSuchMethodException | SecurityException | InstantiationException e) {
					e.printStackTrace();
				}	
		
				Palla be=pcia.getGesogg().getGestionepalle().cercaPalla(res[2]);
				
				if(be.getDirezione()==1) {
		        	pallax= be.getX0()+Crea.convertiMisuraLargh(30);
		            pallay= be.getY0();
					
				}else if(be.getDirezione()==2) {
		        	pallax= be.getX0();
		            pallay= be.getY0()-Crea.convertiMisuraAlt(30);
					
				}else if(be.getDirezione()==3) {
		        	pallax= be.getX0() -Crea.convertiMisuraLargh(30);
		            pallay= be.getY0();
					
				}else if(be.getDirezione()==4) {
		        	pallax=be.getX0();
		            pallay= be.getY0()+Crea.convertiMisuraAlt(30);
					
				}
	        	pallax= be.getX0();
	            pallay= be.getY0();
	            float dx = pallax - x1;
		        float dy = pallay - y1;
		        radianti = Math.atan2(dy, dx);
	            spara();
	        	last=System.currentTimeMillis();
	        	wait=0;
        		}
	        }
        if(sparato) {
        	wait++;
        	last=System.currentTimeMillis();
        	spara();
        	
        }
        
	
		
	}

	private ArrayList<Palla> scoperte(){
		ArrayList<Palla> pa=new ArrayList<Palla>();
		for(int i=0;i<pcia.getGesogg().getGestionepalle().getPalle().size();i++) {
			if(!controlloCoperte(pcia.getGesogg().getGestionepalle().getPallaX(i),pa)) {
				pa.add(pcia.getGesogg().getGestionepalle().getPallaX(i));
			}
		}
		return pa;
	}

	private boolean controlloCoperte(Palla p,ArrayList<Palla> pa){
		for(int j=0;j<pa.size();j++) {
			float ax = pa.get(0).getX0();
		 	float ay = pa.get(0).getY0();
	        float v=8;
	        float i=(float) Math.sqrt((pa.get(0).getX0()-xPi)*(pa.get(0).getX0()-xPi)+(pa.get(0).getY0()-yPi)*(pa.get(0).getY0()-yPi));
	        float cos =(pa.get(0).getX0()-xPi)/i;
	        float sen =(pa.get(0).getY0()-yPi)/i;
	        boolean col=false;
	        while(!col) {
		        ax=ax+cos*v;
		        ay=ay+sen*v;
		        if(pa.get(0).tiHoPreso(ax, ay)) {
		        	return true;
		        }
		        if(pcia.getGesogg().gestionepercorso.fuori(ax, ay)) {
		        	col=true;
		        }
	        }
		}   
		return false;
	}
	protected void nuovoProiettile() {

		ArrayList<Palla> p=new ArrayList<Palla>();
		while(!pcia.getGesogg().getGestionepalle().colorePresente(palle.get(1).getColore())) {
			Random col=new Random();
			int a=col.nextInt(6)+0;
			palle.get(1).setColore(a); 	
		}
		p.add(palle.get(1));
		Random col=new Random();
		int a=col.nextInt(6)+0;
		while(!pcia.getGesogg().getGestionepalle().colorePresente(a)) {
			col=new Random();
			a=col.nextInt(6)+0;
		}
		p.add(new Palla(x,y,a,0,-1));
		p.get(0).setY0((int) (y0-Crea.convertiMisuraAlt(12)));
		p.get(0).setX0((int) (x0-Crea.convertiMisuraLargh(12)));
		palle=p;     
		
	}


	private void spara() {
		
		float ax = palle.get(0).getX0();
	 	float ay = palle.get(0).getY0();
        float v=8;
        float i=(float) Math.sqrt((pallax-xPi)*(pallax-xPi)+(pallay-yPi)*(pallay-yPi));
        float cos =(pallax-xPi)/i;
        float sen =(pallay-yPi)/i;
        ax=ax+cos*v;
        ay=ay+sen*v;
        palle.get(0).sparata(ax, ay);   
        
	}


	@Override
	public void disegna(Graphics gr) {
				
	        Graphics2D g = (Graphics2D)gr;
	        g.setRenderingHint(
	            RenderingHints.KEY_RENDERING, 
	            RenderingHints.VALUE_RENDER_QUALITY);
	        AffineTransform oldAT = g.getTransform();
	        g.translate(x0, y0);
	        g.rotate(radianti);
	        g.translate(-(larghezza/2), -(altezza/2));
	        if(sparato) {
	        	g.drawImage(img[0], 0, 0,(int)larghezza,(int)altezza, null);
	        }else {
	        	g.drawImage(img[1], 0, 0,(int)larghezza,(int)altezza, null);
	        }
	        if((!sparato)||wait<10) {
	        	g.drawImage(Crea.palle[palle.get(0).getColore()],(int)Crea.convertiMisuraLargh(42),(int)Crea.convertiMisuraAlt(23),(int)palle.get(0).getLarghezza(),(int)palle.get(0).getAltezza(), null);
	        }
	        g.drawImage(Crea.palle[palle.get(1).getColore()],(int) Crea.convertiMisuraLargh(13),(int)Crea.convertiMisuraAlt(25), (int)Crea.convertiMisuraLargh(10),(int)Crea.convertiMisuraAlt(10), null);
	        g.setTransform(oldAT);
	        if(sparato&&wait>9) {
	        	gr.drawImage(Crea.palle[palle.get(0).getColore()],(int)palle.get(0).getX0(),(int)palle.get(0).getY0(),(int)palle.get(0).getLarghezza(),(int)palle.get(0).getAltezza(), null);
	        }
	      
	        
	}

	
	@Override
	public void muori() {
		// TODO Auto-generated method stub
		
	}
	
	
	private boolean timermov() {
		
		now=System.currentTimeMillis();
		return !(now-last<4);
		
	}
	
	
//****************GET***************************
	 
	 
	 public Palla getProiettile() {
		 
		 return palle.get(0);
		 
	 }
	 
	 public boolean isColpito() {
		 return colpito;
	 }
	 
	 public int getXPI() {
		 return (int) xPi;
	 }
	
	 public int getYPI() {
		 return (int) yPi;
	 }
	 
//******************************SET**********************	 
	

		public void setColpito(boolean colpito) {
			this.colpito = colpito;
		}



		public void setSparato(boolean colpito) {
			this.sparato = colpito;
		}
		 
		
	 
	}
