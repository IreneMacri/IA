package logica;

import it.unical.mat.embasp.languages.Id;
import it.unical.mat.embasp.languages.Param;

@Id("distanzaLarghezza")
public class DistanzaLarghezza {
	@Param(0)
	protected int d;
	@Param(1)
	protected int d1;
	public DistanzaLarghezza(int d , int d1) {
		this.d = d; 
		this.d1 = d1; 
	}
	public int getD() {
		return d;
	}
	public void setD(int d) {
		this.d = d;
	}
	public int getD1() {
		return d1;
	}
	public void setD1(int d1) {
		this.d1 = d1;
	}
}
