package logica;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;

import disegnafacile.Pezzo;
import disegnafacile.SpCurva1;
import disegnafacile.SpCurva2;
import disegnafacile.SpCurva3;
import disegnafacile.SpCurva4;
import disegnafacile.SpFine;
import disegnafacile.SpInizio;
import disegnafacile.SpOrizzontale;
import disegnafacile.SpVerticale;
import richiamafacile.Crea;
import richiamafacile.LeggiFile;

public class GestionePercorso{

	private int[][] caselle;
	private int larghezza,altezza;
	protected int vaix,vaiy,inx,iny,finx,finy,posfin;
	private ArrayList<Pezzo> percorso;
	
		
	public GestionePercorso(String pos) {
		
		caricaStage(pos);
		preparaCaselle();
		
	}
	
	public void aggiorna() {

		
	}
		
	public void disegna(Graphics g) {
		
		for(int i=0;i<percorso.size();i++) {
			percorso.get(i).disegna(g);
		}
		
	}
	
	
	public void caricaStage(String pos) {
		
		String file;
		file=LeggiFile.posizionefile(pos);
		String[] pezzo=file.split("\\s+");
		larghezza=25;
		altezza=20;
		caselle =new int[larghezza][altezza];
		for(int i=0;i<altezza;i++) {
			for(int j=0;j<larghezza;j++) {
				caselle[j][i]=LeggiFile.parseInt(pezzo[(j+(i*larghezza))]);
			}
		}
		
	}
	
	
	public void preparaCaselle() {
		
		percorso=new ArrayList<Pezzo>();
		for(int i=0;i<larghezza;i++) {
			for(int j=0;j<altezza;j++) {
				if(caselle[i][j]==1) {
					inx=i;
					iny=j;
					percorso.add(new SpInizio(i,j));
				}else if(caselle[i][j]==2) {
					percorso.add(new SpOrizzontale(i,j));
				}else if(caselle[i][j]==3){
					percorso.add(new SpCurva1(i,j));	
				}else if(caselle[i][j]==4){
					percorso.add(new SpCurva2(i,j));
				}else if(caselle[i][j]==5){
					percorso.add(new SpCurva4(i,j));
				}else if(caselle[i][j]==6){
					percorso.add(new SpCurva3(i,j));
				}else if(caselle[i][j]==7){
					finx=i;
					finy=j;
					posfin=i+j;
					double ruota=0;
					if(getCasella(i+1,j)==2||getCasella(i+1,j)==3||getCasella(i+1,j)==6) {
						ruota=270;
					}else if(getCasella(i-1,j)==2||getCasella(i-1,j)==4||getCasella(i-1,j)==5) {
						ruota=90;
					}else if(getCasella(i,j-1)==8||getCasella(i,j-1)==5||getCasella(i,j-1)==3) {
						ruota=180;
					}else if(getCasella(i,j+1)==8||getCasella(i,j+1)==4||getCasella(i,j+1)==6) {
						ruota=0;
					}	
					percorso.add(new SpFine(i,j,ruota));
				}else if(caselle[i][j]==8){
					percorso.add(new SpVerticale(i,j));
				}else if(caselle[i][j]==9){
					vaix=i;
					vaiy=j;
				}		
			}
		}	
		
	}
	
		


	public boolean fuori(Palla p) {
		if(p.getX0()<0||(p.getX0()>larghezza*percorso.get(0).getLarghezza())||p.getY0()<0||(p.getY0()>altezza*percorso.get(0).getAltezza()+Crea.convertiMisuraAlt(48)))
			return true;
		return false;
	}
	
	public boolean fuori(float a, float b) {
		if(a<0||(a>larghezza*percorso.get(0).getLarghezza())||b<0||(b>altezza*percorso.get(0).getAltezza()+Crea.convertiMisuraAlt(48)))
			return true;
		return false;
	}
	
	public int decimi(int a,int b) {
		
		return (int)(percorso.get(cerca(a,b)).getValore()/(percorso.size()/9));
		
		
	}
	
	
	public void apriBocca(int a,int b) {
		
		
		setBocca(decimi(a,b));
		//System.out.println(decimi(a,b));
	}
	
		
//********************SET*******************************************


	private void setBocca(int a) {
		
		percorso.get(cerca(finx,finy)).setDecimi(a);
				
	}

	public void setValoreP(int co,int x,int y) {
		
		percorso.get(cerca(x,y)).setValore(co);
	}

	private int cerca(int x, int y) {
		for(int i=0;i<percorso.size();i++) {
			if(percorso.get(i).getX()==x&&percorso.get(i).getY()==y)
				return i;
		}
		return -1;
	}

	

	
	
	//*********************GET*****************************************
			
		public int getCeInY() {
			
			return (int)((percorso.get(0).getAltezza()*(iny))+(percorso.get(0).getAltezza()/2)+Crea.convertiMisuraAlt(48));
		
		}
		
		
		public int getCeInX() {
		
			return (int)((percorso.get(0).getLarghezza()*(inx))+(percorso.get(0).getLarghezza()/2));
		
		}
		public int getInx() {
			return inx;
		}

		public int getIny() {
			return iny;
		}

		public int getFinx() {
			return finx;
		}

		public int getFiny() {
			return finy;
		}

		public int getAltezza() {
			return altezza;
		}
		
		
		public int getLarghezza() {
			return larghezza;
		}
		
		public int getAl() {
			return (int)percorso.get(0).getAltezza();
		}
		
		
		public int getLa() {
			return (int)percorso.get(0).getLarghezza();
		}
		
		
		public int getVaix() {
			return vaix;
		}
		
		public int getVaiy() {
			return vaiy;
		}
		
		public int getCasella(int a,int b) {
			if(a>larghezza||a<0||b<0||b>altezza)
				return 0;
			return caselle[a][b];
		}
		
		public int[][] getCaselle() {
			return caselle;
		}
	

	
	
}

