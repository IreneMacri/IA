package logica;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import it.unical.mat.embasp.base.Handler;
import it.unical.mat.embasp.base.InputProgram;
import it.unical.mat.embasp.base.OptionDescriptor;
import it.unical.mat.embasp.base.Output;
import it.unical.mat.embasp.languages.asp.ASPInputProgram;
import it.unical.mat.embasp.languages.asp.AnswerSet;
import it.unical.mat.embasp.languages.asp.AnswerSets;
import it.unical.mat.embasp.platforms.desktop.DesktopHandler;
import it.unical.mat.embasp.specializations.dlv2.desktop.DLV2DesktopService;

public class IA {
	private String encodingResource = "Intelligente/zuma.txt";
	private Handler handler; 
	protected Output output; 
	private AnswerSets answersets; 
	private InputProgram program; 
	OptionDescriptor filter; 
	InputProgram facts; 
	
	public IA() {
		handler = new DesktopHandler(new DLV2DesktopService("Intelligente/dlv2"));
		facts = new ASPInputProgram(); 
		program = new ASPInputProgram() ;
		program.addFilesPath(encodingResource);
		filter = new  OptionDescriptor(new String ("--filter=spara/3 ")); 
		handler.addProgram(program); 
		handler.addOption(filter); 
	}
	public int[] executeDLV(ArrayList<Palla> palle, Palla proiettile, int distanzaAltezza, int scartoAltezza, int distanzaLarghezza, int scartoLarghezza, int s1, int s2) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, InstantiationException {
		facts =  new ASPInputProgram(); 
		for (Palla p : palle) {
			
			try {
				int x= (int) p.getX0();
				int y = (int) p.getY0(); 
				facts.addObjectInput(new Palla(x,y,p.getColore(),p.getDirezione(),p.getValore()));
				
		 	} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		try {
			facts.addObjectInput(new DistanzaAltezza(distanzaAltezza,scartoAltezza));
			facts.addObjectInput(new DistanzaLarghezza(distanzaLarghezza,scartoLarghezza));
			facts.addObjectInput(new ScartoAltezza(s2));
			facts.addObjectInput(new ScartoLarghezza(s1));
			facts.addObjectInput(new Proiettile((int)proiettile.getX0(),(int)proiettile.getY0(),proiettile.getColore()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		handler.addProgram(facts); 
		output = handler.startSync(); 
	
		AnswerSets answers = (AnswerSets) output;
		List<AnswerSet> answer = answers.getAnswersets(); 
		String prova = answers.getOutput();
		System.out.println(prova);
		String [] results = prova.split("\\D+");
		int [] res  = new int [3]; 
		res[0] = Integer.parseInt(results[1]); 
		res[1] = Integer.parseInt(results[2]); 
		res[2] = Integer.parseInt(results[3]); 
		handler.removeProgram(facts); 
		facts.clearAll();
		return res; 
	}
	public void setFacts(ArrayList<Palla> palle, Palla proiettile, int distanzaAltezza, int scartoAltezza, int distanzaLarghezza, int scartoLarghezza) {
		facts =  new ASPInputProgram(); 
		for (Palla p : palle) {
		int x= (int) p.getX0();
		int y = (int) p.getY0(); 
		try {
			facts.addObjectInput(new Palla(x,y,p.getColore(),p.getDirezione(),p.getValore()));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		try {
			facts.addObjectInput(new DistanzaAltezza(distanzaAltezza,scartoAltezza));
			facts.addObjectInput(new DistanzaLarghezza(distanzaLarghezza,scartoLarghezza));
			facts.addObjectInput(new Proiettile((int)proiettile.getX0(),(int)proiettile.getY0(),proiettile.getColore()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		handler.addProgram(facts); 
		output = handler.startSync(); 
		handler.removeProgram(facts); 
		facts.clearAll();
	}
}
