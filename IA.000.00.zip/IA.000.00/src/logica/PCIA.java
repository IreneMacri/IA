package logica;

import schermo.Mouse;

public class PCIA {

	private static Game game;
	private Stage stage;
	protected int nstage;
	protected GestisciOggetti gesogg;
	
	public PCIA(Game game) {
		this.game=game;
	}

//***************GET**************************************	
	public Game getGame() {
		return game;
	}

	public Stage getStage() {
		return stage;
	}
	
	public int getNStage() {
		return nstage;
	}
	
	public static int getAltezza() {
		return game.getAltezza();
	}
	
	public static int getLarghezza() {
		return game.getLarghezza();
	}
	
	public Mouse getMouse() {
		return game.getMouse();
	}

	public GestisciOggetti getGesogg() {
		return gesogg;
	}

	public void setGesogg(GestisciOggetti gesogg) {
		this.gesogg = gesogg;
	}

	//***********************SET*******************************	
	public void setGame(Game game) {
		this.game = game;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}
	
	public void setNStage(int nstage) {
		this.nstage = nstage;
	}
}
