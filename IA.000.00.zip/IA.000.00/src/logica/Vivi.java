package logica;

public class Vivi {
	public static int larghezza=800; 
	public static int altezza=720;

	public static void main(String[] args) {
		Game game=new Game("IA",larghezza,altezza);
		game.start();

	}

}
