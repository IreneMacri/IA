package logica;

import java.awt.Graphics;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

import it.unical.mat.embasp.languages.asp.ASPInputProgram;
import richiamafacile.Crea;
import schermo.Stato;
import stati.StatoGioco;
import stati.StatoMenu;

public class GestisciOggetti {

	protected boolean attivo,modifica=false;
	private Giocatore giocatore;
	protected int score;
	protected PCIA pcia;
	public IA ia; 
	
	protected GestionePercorso gestionepercorso;

	protected GestionePalle gestionepalle;
	
	

		
		
	public GestisciOggetti(String pos,int a,PCIA pcia) {
		
		this.attivo=true;
		this.pcia=pcia;
		score=0;
		gestionepercorso=new GestionePercorso(pos);
		ia = new IA(); 
		gestionepalle=new GestionePalle(gestionepercorso,a);
		gestionepercorso=gestionepalle.getGes();
		pcia.setGesogg(this);
		this.giocatore=new Giocatore(gestionepercorso.getVaix(),gestionepercorso.getVaiy(),Crea.player,pcia);
	}
	


	public void aggiorna() {
		if(!attivo)
			return;
		gestionepalle.aggiorna();
		gestionepercorso.aggiorna();
		gestionepercorso.apriBocca((int)gestionepalle.getPrimaPalla().getX(), (int)gestionepalle.getPrimaPalla().getY());
		//System.out.println(metodoBello());
		if(!gestionepalle.parti()) {
			//System.out.println(gestionepalle.getPrimaPalla().getX0() +  " " + gestionepalle.getPrimaPalla().getY0());
			
			//ia.setFacts(gestionepalle.getPalle(), giocatore.getProiettile(),(int) gestionepalle.getPrimaPalla().getAltezza(), s1,(int) gestionepalle.getPrimaPalla().getLarghezza(), s2);
			
			if(giocatore.isColpito()) {
				
			}
			
			giocatore.aggiorna();
			
		}
		if(gestionepalle.interseca(giocatore.getProiettile())) {
			giocatore.setColpito(true);
			int a=gestionepalle.getPosizioneColpita(giocatore.getProiettile());
			gestionepalle.controlloTris(a,giocatore.getProiettile().getColore());
			if(gestionepalle.getCont()<3 ) {
				gestionepalle.aggiungiPalla(giocatore.getProiettile(),a);
			}else {
				score+=gestionepalle.getCont()*10;
				modifica=true;
			}
		}
		if(gestionepercorso.fuori(giocatore.getProiettile())) {
			giocatore.setColpito(true);
		}
			
	}
	
	
	public void disegna(Graphics g) {
		
		gestionepercorso.disegna(g);
		gestionepalle.disegna(g);
		giocatore.disegna(g);
		if(gestionepalle.parti()) {
			gestionepalle.disegnaDown(g);
		}

		
		
	}
	
		
	public ArrayList<Palla> metodoBello(){
		
		ArrayList<Palla> rag=gestionepalle.getPalle();
		ArrayList<Palla> signore=new ArrayList<Palla>();
		for(int j=0;j<rag.size();j++) {
			boolean ok=false;
			float ax = giocatore.getProiettile().getCentroX();
		 	float ay = giocatore.getProiettile().getCentroY();
			while(ok) {
		        float v=8;
		        float i=(float) Math.sqrt((rag.get(j).getX0()-giocatore.getXPI())*(rag.get(j).getX0()-giocatore.getXPI())+(rag.get(j).getY0()-giocatore.getYPI())*(rag.get(j).getY0()-giocatore.getYPI()));
		        float cos =(rag.get(j).getCentroX()-giocatore.getXPI())/i;
		        float sen =(rag.get(j).getCentroY()-giocatore.getYPI())/i;
		        ax=ax+cos*v;
		        ay=ay+sen*v;

		        if(gestionepercorso.fuori(ax,ay)) {
		        	ok=false;
		        }

				for(int h=0;h<rag.size();h++) {
		        if(rag.get(h).isAttivo()&& !rag.get(h).tiHoPreso(ax, ay)) {
		        	ok=false;
		        	if(!davanti(signore)) {
		        		signore.add(rag.get(h));
		        	}	
		        }
			}
		}
		}
	return signore;
			
	}
	     
	
	
	public boolean davanti(ArrayList<Palla> q) {
		for(int j=0;j<q.size();j++) {
			boolean ok=false;
			float ax = giocatore.getProiettile().getCentroX();
		 	float ay = giocatore.getProiettile().getCentroY();
			while(!ok) {
		        float v=8;
		        float i=(float) Math.sqrt((q.get(j).getX0()-giocatore.getXPI())*(q.get(j).getX0()-giocatore.getXPI())+(q.get(j).getY0()-giocatore.getYPI())*(q.get(j).getY0()-giocatore.getYPI()));
		        float cos =(q.get(j).getCentroX()-giocatore.getXPI())/i;
		        float sen =(q.get(j).getCentroY()-giocatore.getYPI())/i;
		        ax=ax+cos*v;
		        ay=ay+sen*v;

		        if(gestionepercorso.fuori(ax,ay)) {
		        	ok=true;
		        }

				for(int h=0;h<q.size();h++) {
			        if(q.get(h).tiHoPreso(ax, ay)) {
			        	return true;	
			        }
				}
			}
		}
		return false;
		
	}
//*********************GET*****************

	
	
	public boolean isPerso() {
		
		if(!gestionepalle.finito()) {
			return ((int)gestionepalle.getPrimaPalla().getX())==gestionepercorso.getFinx()&& ((int)gestionepalle.getPrimaPalla().getY())==gestionepercorso.getFiny();
		}
		return false;
	}


	public GestionePalle getGestionepalle() {
		return gestionepalle;
	}



	public boolean isVinto() {
		
		return gestionepalle.finito();
	}


	public int getScore() {
		
		return score;
		
	}

	public int getCont() {
		
		return gestionepalle.getCont();
	}


	public boolean isModifica() {
		return modifica;
	}

	
	
//********************SET********************


	public void setModifica(boolean modifica) {
		this.modifica = modifica;
	}



	public void setScore(int score) {
		this.score = score;
	}

	
	}
