package logica;

import it.unical.mat.embasp.languages.Id;
import it.unical.mat.embasp.languages.Param;

@Id("scartoLarghezza")
public class ScartoLarghezza {

	@Param(0)
	protected int d3; 
	
	public ScartoLarghezza(int d3) {
		this.d3 = d3; 
	}

	public int getD3() {
		return d3;
	}

	public void setD3(int d3) {
		this.d3 = d3;
	}
}
