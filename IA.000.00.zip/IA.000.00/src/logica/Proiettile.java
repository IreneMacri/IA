package logica;

import it.unical.mat.embasp.languages.Id;
import it.unical.mat.embasp.languages.Param;

@Id("proiettile")
public class Proiettile {

	@Param(0)
	protected int x0;
	@Param(1)
	protected int y0;
	@Param(2)
	protected int colore;
	
	public Proiettile(int x, int y, int c) {
		super();
		this.x0 = x; 
		this.y0 = y; 
		this.colore = c; 
	}
	public void setX0(int X0) {
		this.x0 = X0; 
	}
	public void setY0(int Y0) {
		this.y0 = Y0; 
	}
	public void setColore(int c) {
		this.colore = c; 
	}
	public int getX0() {
		return x0;
	}
	public int getY0() {
		return y0;
	}
	public int getColore() {
		return colore;
	}
}
