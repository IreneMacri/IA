package logica;

import java.awt.Rectangle;

import richiamafacile.Crea;

public abstract class Popolo extends Oggetti {
	
	public static final int larghezza_default=32, altezza_default=32;
	public static final float velocita_default=3.0f;

	protected boolean colpito=false;
	protected float co=0;
	protected float velocita;
	protected float versox,versoy;
	protected int direzione=0;
	

	public Popolo(float x, float y,float l, float a) {
		super(x, y,l,a);
		
		velocita=Crea.convertiMisuraLargh(velocita_default);
		this.versox=0;
		this.versoy=0;
		
	}
	
	public abstract void muovi();
	
	public abstract void muoviX(); 
	
	public void muoviY() {
	}	

	
	
	
//***************GET****************	
	public int getVita() {
		return vita;
	}

	public float getVelocita() {
		return velocita;
	}

	public float getVersoX() {
		return versox;
	}

	public float getVersoY() {
		return versoy;
	}
	
	public int getDirezione() {
		return direzione;
	}

//***************SET**************	
	public void setVita(int vita) {
		this.vita = vita;
	}

	public void setVelocita(float velocita) {
		this.velocita = velocita;
	}

	public void setVersoX(int x) {
		this.versox = x;
	}

	public void setVersoY(int y) {
		this.versoy = y;
	}
	
	
}
