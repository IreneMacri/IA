package logica;

import java.awt.Graphics;

import disegnafacile.Pezzo;
import it.unical.mat.embasp.languages.Id;
import it.unical.mat.embasp.languages.Param;
import richiamafacile.Crea;

@Id("palla")

public class Palla extends Oggetti{
	
	
	private static double velocita_def=1.0;
	
	
	protected boolean pausa=false;
	protected double velocita;
	@Param(0)
	protected int x0;
	@Param(1)
	protected int y0;
	@Param(2)
	protected int colore;
	@Param(3)
	protected int direzione=0;
	@Param(4)
	protected int valore;
	public Palla(int x, int y,int colore,int direzione) {
	
		super(); 
		this.x0 =  x; 
		this.y0 =  y; 
		this.colore  = colore; 
		this.direzione=direzione;
	 
	}
	
	public Palla(float x, float y,int colore,int direzione,int valore) {
		
		super(x, y, 24,24);
		attivo=false;
		this.valore=valore;
		this.direzione=direzione;
		x0=(int) ((int) x*Crea.convertiMisuraLargh(Pezzo.larghezza_default)+Crea.convertiMisuraLargh(Pezzo.altezza_default)/2-(larghezza/2));
		y0=(int) ((int) y*Crea.convertiMisuraAlt(Pezzo.altezza_default)+Crea.convertiMisuraAlt(48)+Crea.convertiMisuraAlt(Pezzo.altezza_default)/2-altezza/2);
		
		this.colore=colore;
		velocita=velocita_def;
		
	}

	
	@Override
	public void aggiorna() {
		if(!pausa&&attivo) {
			if(direzione==1) {
				x0+=velocita;
			}else if(direzione==2) {
				y0+=velocita;
			}else if(direzione==3) {
				x0-=velocita;
			}else if(direzione==4) {
				y0-=velocita;
			}
			x=(int)x0/Crea.convertiMisuraLargh(Pezzo.larghezza_default);
			y=(int)(y0-Crea.convertiMisuraAlt(48))/Crea.convertiMisuraAlt(Pezzo.altezza_default);
		}	
		
	}

	public void setDirezione(int direzione) {
		this.direzione = direzione;
	}

	@Override
	public void disegna(Graphics g) {
		g.drawImage(Crea.palle[colore], (int)x0,(int)y0,(int)larghezza,(int)altezza, null);
		
	}

	public void sparata(float x, float y) {
		x0=(int) x;
		y0=(int) y;
       
	}
	
	
	@Override
	public void muori() {
		// TODO Auto-generated method stub
		
	}
	

	public float getCentroX() {
		
		return (x0+larghezza/2);
		
	}


	public float getCentroY() {
		
		return (y0+altezza/2);
		
	}
	
	public int getDirezione() {
		
		return direzione;
		
	}

	public boolean isPausa() {
		
		return pausa;
		
	}
	
	public int getX0() {
		
		return x0;
	
	}

	public int getY0() {
		
		return y0;
		
	}


	public int getColore() {
		
		return colore;
		
	}



	public int getValore() {
		
		return valore;
	
	}
	
	
	
//***********************************SET*************************
	

	public void setX0(int x0) {
		this.x0 = x0;
	}


	public void setY0(int y0) {
		this.y0 =  y0;
	}


	public boolean tiHoPreso(float ax,float ay) {
		if(ax>=x0&&ax<=(x0+larghezza)&&ay>=y0&&ay<=(y0+altezza)) {
			return true;
		}
		return false;
	}

	public void setValore(int valore) {
		
		this.valore = valore;
	
	}


	public void setPausa(boolean pausa) {
		this.pausa = pausa;
	}

	public void setColore(int a) {
		this.colore = a; 
	}
	
	


	
		

}
