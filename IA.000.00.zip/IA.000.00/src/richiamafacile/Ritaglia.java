package richiamafacile;

import java.awt.image.BufferedImage;

public class Ritaglia {
	
	private BufferedImage img;
	
	public Ritaglia(BufferedImage img) {
		this.img=img;
	}

	public BufferedImage taglia(int x,int y,int larghezza,int altezza) {
		return img.getSubimage(x, y, larghezza, altezza);
	}
}
