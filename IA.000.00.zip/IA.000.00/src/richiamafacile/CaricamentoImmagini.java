package richiamafacile;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class CaricamentoImmagini {
	
	public static BufferedImage carica(String posizione) {
			try {
				return (ImageIO.read(CaricamentoImmagini.class.getResource(posizione)));
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(1);
			}	
			return null;
	}
 
}