package richiamafacile;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.font.LineBreakMeasurer;
import java.awt.font.TextLayout;
import java.text.AttributedCharacterIterator;
import java.text.AttributedString;

public class Testo {

	public static void drawString(Graphics g,String txt,float x,float y,boolean centro,Color c,Font f) {
		g.setColor(c);
		g.setFont(f);
		int xpos=(int)x;
		int ypos=(int)y;
		if (centro) {
			FontMetrics fm=g.getFontMetrics(f);
			xpos= (int)(x-fm.stringWidth(txt)/2);
			ypos=(int)((y-fm.getHeight()/2)+fm.getAscent());
		}
		g.drawString(txt, xpos, ypos);
	}
	
	public static void drawStringR(Graphics2D g,String txt,Rectangle rect,Color c,Font f) {
		g.setColor(c);
		g.setFont(f);
		int l = (int)rect.getWidth();
		String [] parole = txt.split(" ");
		int tmp = 0;
		int xCorrente = 0;
		int yCorrente = g.getFontMetrics().getHeight();
		while (tmp < parole.length) {
		if (g.getFontMetrics().stringWidth(parole [tmp]) < (l - xCorrente)) {
			g.drawString (parole [tmp] + " " , rect.x + xCorrente , rect.y + yCorrente);
			xCorrente += g.getFontMetrics().stringWidth(parole [tmp] + " ");
			tmp++;
		}else {
			xCorrente = 0;
			yCorrente += g.getFontMetrics().getHeight() + 2;
			continue;
			}
		}
		}
	
}

