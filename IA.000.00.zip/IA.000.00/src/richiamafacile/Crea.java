package richiamafacile;

import java.awt.Font;
import java.awt.image.BufferedImage;

import javax.sound.sampled.Clip;

import richiamafacile.CaricamentoImmagini;
import logica.PCIA;
import logica.Vivi;


public class Crea {
	
	public static final int larghezza=32,altezza=32;
	
	public static BufferedImage sfondo0,sfondomenu,fondo0,sfondolivello,sfondovittoria;
	public static BufferedImage[] play;
	public static BufferedImage[] scelta;
	public static BufferedImage[] exit;
	public static BufferedImage[] player;
	public static BufferedImage[] livello;
	public static BufferedImage[] back;
	public static BufferedImage[] bottonemenu;

	public static BufferedImage[] palle;
	
	public static BufferedImage[] contoallarovescia;
	
	public static BufferedImage curva1,curva2,curva3,curva4,spinizio,sporizzontale,spverticale;
	public static BufferedImage[] spfine;
	
	
	public static Font font,font2,font3;
	
	
	public static void inizializza() {
		
		//inizializza variabili per i vettori
			play=new BufferedImage[2];
			scelta=new BufferedImage[2];
			exit=new BufferedImage[2];
			livello=new BufferedImage[2];
			back=new BufferedImage[2];
			
			bottonemenu=new BufferedImage[2];
			
			spfine=new BufferedImage[11];
			
			player=new BufferedImage[2];

			palle=new BufferedImage[6];

			contoallarovescia=new BufferedImage[8];
			
			sfondomenu=CaricamentoImmagini.carica("/img/sfondomenu.png");
			sfondolivello=CaricamentoImmagini.carica("/img/sfondobello.jpg");
			sfondovittoria=CaricamentoImmagini.carica("/img/sfondovittoria.jpg");
			sfondo0=CaricamentoImmagini.carica("/img/basestage0.png");
			fondo0=CaricamentoImmagini.carica("/img/sfondostage0.png");
			
			
			palle [0]=CaricamentoImmagini.carica("/img/palla1.png");
			palle [1]=CaricamentoImmagini.carica("/img/palla2.png");
			palle [2]=CaricamentoImmagini.carica("/img/palla3.png");
			palle [3]=CaricamentoImmagini.carica("/img/palla4.png");
			palle [4]=CaricamentoImmagini.carica("/img/palla5.png");
			palle [5]=CaricamentoImmagini.carica("/img/palla6.png");
			

			bottonemenu [0]=CaricamentoImmagini.carica("/img/bottone_menu.png");
			bottonemenu [1]=CaricamentoImmagini.carica("/img/bottone_menu1.png");
			
			play [0]=CaricamentoImmagini.carica("/img/play1.png");
			play [1]=CaricamentoImmagini.carica("/img/play2.png");

			livello [0]=CaricamentoImmagini.carica("/img/livello1.png");
			livello [1]=CaricamentoImmagini.carica("/img/livello2.png");
			
			exit [0]=CaricamentoImmagini.carica("/img/exit2.png");
			exit [1]=CaricamentoImmagini.carica("/img/exit1.png");
			
			scelta [0]=CaricamentoImmagini.carica("/img/scelta1.png");
			scelta [1]=CaricamentoImmagini.carica("/img/scelta2.png");
			
			player [0]=CaricamentoImmagini.carica("/img/player0.png");
			player [1]=CaricamentoImmagini.carica("/img/player0.png");
			
			curva1=CaricamentoImmagini.carica("/img/curva1.png");
			curva2=CaricamentoImmagini.carica("/img/curva2.png");
			curva3=CaricamentoImmagini.carica("/img/curva3.png");
			curva4=CaricamentoImmagini.carica("/img/curva4.png");
			spinizio=CaricamentoImmagini.carica("/img/spinizio.png");
			sporizzontale=CaricamentoImmagini.carica("/img/sporizzontale.png");
			spverticale=CaricamentoImmagini.carica("/img/spverticale.png");
			spfine[0]=CaricamentoImmagini.carica("/img/spfine.png");
			spfine[1]=CaricamentoImmagini.carica("/img/spfine1.png");
			spfine[2]=CaricamentoImmagini.carica("/img/spfine2.png");
			spfine[3]=CaricamentoImmagini.carica("/img/spfine3.png");
			spfine[4]=CaricamentoImmagini.carica("/img/spfine4.png");
			spfine[5]=CaricamentoImmagini.carica("/img/spfine5.png");
			spfine[6]=CaricamentoImmagini.carica("/img/spfine6.png");
			spfine[7]=CaricamentoImmagini.carica("/img/spfine7.png");
			spfine[8]=CaricamentoImmagini.carica("/img/spfine8.png");
			spfine[9]=CaricamentoImmagini.carica("/img/spfine9.png");
			spfine[10]=CaricamentoImmagini.carica("/img/spfine10.png");
			
			contoallarovescia [0]=CaricamentoImmagini.carica("/img/start1.png");
			contoallarovescia [1]=CaricamentoImmagini.carica("/img/start2.png");
			contoallarovescia [2]=CaricamentoImmagini.carica("/img/start3.png");
			contoallarovescia [3]=CaricamentoImmagini.carica("/img/start4.png");
			contoallarovescia [4]=CaricamentoImmagini.carica("/img/start5.png");
			contoallarovescia [5]=CaricamentoImmagini.carica("/img/start6.png");
			contoallarovescia [6]=CaricamentoImmagini.carica("/img/start7.png");
			contoallarovescia [7]=CaricamentoImmagini.carica("/img/start8.png");

			back [0]=CaricamentoImmagini.carica("/img/back1.png");
			back [1]=CaricamentoImmagini.carica("/img/back2.png");
			
			

			font=CaricaFont.Carica("/txt/slkscrb.ttf",13);
			font2=CaricaFont.Carica("/txt/slkscreb.ttf",18);
			font3=CaricaFont.Carica("/txt/slkscrb.ttf",32);
			
	}
	
	
	public static float convertiMisuraAlt(float a) {
		return ((a*PCIA.getAltezza())/Vivi.altezza);
	}
	
	public static float convertiMisuraLargh(float a) {
		return ((a*PCIA.getLarghezza())/Vivi.larghezza);
	}

}
