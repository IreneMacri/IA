package richiamafacile;

import java.awt.Font;
import java.awt.FontFormatException;
import java.io.File;
import java.io.IOException;
import java.net.URL;

public class CaricaFont {

	public static Font Carica(String pos, float dim ) {
		try {
			
			return Font.createFont(Font.TRUETYPE_FONT, CaricaFont.class.getResourceAsStream(pos)).deriveFont(Font.ITALIC,dim);
		}catch(FontFormatException|IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		return null;
	}
	
}
