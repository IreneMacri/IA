	package richiamafacile;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;

public class SuppFile {

	  public static void test (String path) {
		    int iniziale, finale, incremento;
		    iniziale = 0;
		    finale = 10; 
		    incremento = 2;
		  
		    try {
		      FileOutputStream file = new FileOutputStream(path);
		      @SuppressWarnings("resource")
			PrintStream Output = new PrintStream(file);
		  
		      while (iniziale <= finale) { 
		        Output.println(iniziale);
		        iniziale = iniziale + incremento;
		      }

		    } catch (IOException e) {
		      System.out.println("Errore: " + e);
		      System.exit(1);
		    }
		  } 

	public static void newFile(String path) {
	    try {
	        File file = new File(path);
	         
	        if (file.exists())
	            System.out.println("Il file " + path + " esiste");
	        else if (file.createNewFile())
	            System.out.println("Il file " + path + " � stato creato");
	       
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	
	public static void cancella(String path) {
	    File file = new File(path);
		file.delete();
	}
	
	public static boolean esiste(String path) {
	    File file = new File(path);
		return file.exists();
	}
	
	public static void scriviRiga(String path,String txt) {

	      FileInputStream fstream = null; 
	      DataInputStream in = null;
	      BufferedWriter out = null;
	    
	      try {
	         // apro il file
	         fstream = new FileInputStream(path);
	     
	         // prendo l'inputStream
	         in = new DataInputStream(fstream);
	         BufferedReader br = new BufferedReader(new InputStreamReader(in));
	         String strline;
	         StringBuilder fileContent = new StringBuilder();
	     
	         // Leggo il file riga per riga
	         while ((strline = br.readLine()) != null) {
	  	            fileContent.append(strline);
			        fileContent.append(System.getProperty("line.separator"));
		         }

	            fileContent.append(txt);
		        fileContent.append(System.getProperty("line.separator"));
	         // Sovrascrivo il file con il nuovo contenuto (aggiornato)
	         FileWriter fstreamWrite = new FileWriter(path);
	         out = new BufferedWriter(fstreamWrite);
	         out.write(fileContent.toString());
	     
	      } catch (Exception e) {
	         e.printStackTrace();
	 
	      } finally {
	         // chiusura dell'output e dell'input
	         try {
	            fstream.close();
	            out.flush();
	            out.close();
	            in.close();
	         } catch (IOException e) {
	            e.printStackTrace();
	         }
	      }
	}
	
	public static void svuotaFile(String path) {
	     
	    try {
	        File file = new File(path);
	        FileWriter fw = new FileWriter(file);
	        BufferedWriter bw = new BufferedWriter(fw);
	        bw.write("");
	        bw.flush();
	        bw.close();
	    }
	    catch(IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public static void iniAccount(String path) {
	     
	    try {
	        File file = new File(path);
	        FileWriter fw = new FileWriter(file);
	        BufferedWriter bw = new BufferedWriter(fw);
	        bw.write("nome=");
            bw.append(System.getProperty("line.separator"));
	        bw.write("cassa=");
            bw.append(System.getProperty("line.separator"));
	        bw.write("volmusica=");
            bw.append(System.getProperty("line.separator"));
	        bw.write("voleffetti=");
            bw.append(System.getProperty("line.separator"));
	        bw.write("persatt=");
            bw.append(System.getProperty("line.separator"));
	        bw.write("persblo=");
            bw.append(System.getProperty("line.separator"));
	        bw.write("livsblo=");
            bw.append(System.getProperty("line.separator"));
	        bw.write("livpun=");
	        bw.flush();
	        bw.close();
	    }
	    catch(IOException e) {
	        e.printStackTrace();
	    }
	}

	
	public static void modifica(String a,String b,String path) {
	    
	      FileInputStream fstream = null; 
	      DataInputStream in = null;
	      BufferedWriter out = null;
	    
	      try {
	         // apro il file
	         fstream = new FileInputStream(path);
	     
	         // prendo l'inputStream
	         in = new DataInputStream(fstream);
	         BufferedReader br = new BufferedReader(new InputStreamReader(in));
	         String strline;
	         StringBuilder fileContent = new StringBuilder();
	     
	         // Leggo il file riga per riga
	         boolean ok=false;
	         while ((strline = br.readLine()) != null||!ok) {
	        	boolean tro=true;
	        	int i=0;
	        	while(i<a.length()&&tro) {
	        		if(strline.charAt(i)!=a.charAt(i)) {
	        			tro=false;
	        		}
	        	i++;
	        	} 
	        	if(tro) {
	        		ok=true;
			          fileContent.append(a+b+System.getProperty("line.separator"));
			            } else {
			               // ... altrimenti la trascrivo cos� com'�
			               fileContent.append(strline);
			               fileContent.append(System.getProperty("line.separator"));
			            }
		         }
	  
	         // Sovrascrivo il file con il nuovo contenuto (aggiornato)
	         FileWriter fstreamWrite = new FileWriter(path);
	         out = new BufferedWriter(fstreamWrite);
	         out.write(fileContent.toString());
	     
	      } catch (Exception e) {
	         e.printStackTrace();
	 
	      } finally {
	         // chiusura dell'output e dell'input
	         try {
	            fstream.close();
	            out.flush();
	            out.close();
	            in.close();
	         } catch (IOException e) {
	            e.printStackTrace();
	         }
	      }
	   }
	
	public static void cancellaRiga(String path,String a) {
	    
	      FileInputStream fstream = null; 
	      DataInputStream in = null;
	      BufferedWriter out = null;
	    
	      try {
	         // apro il file
	         fstream = new FileInputStream(path);
	     
	         // prendo l'inputStream
	         in = new DataInputStream(fstream);
	         BufferedReader br = new BufferedReader(new InputStreamReader(in));
	         String strline;
	         StringBuilder fileContent = new StringBuilder();
	     
	         // Leggo il file riga per riga
	         while ((strline = br.readLine()) != null) {
	        	if(!strline.equals(a)){
			               fileContent.append(strline);
			               fileContent.append(System.getProperty("line.separator"));
			            }
		         }
	  
	         // Sovrascrivo il file con il nuovo contenuto (aggiornato)
	         FileWriter fstreamWrite = new FileWriter(path);
	         out = new BufferedWriter(fstreamWrite);
	         out.write(fileContent.toString());
	     
	      } catch (Exception e) {
	         e.printStackTrace();
	 
	      } finally {
	         // chiusura dell'output e dell'input
	         try {
	            fstream.close();
	            out.flush();
	            out.close();
	            in.close();
	         } catch (IOException e) {
	            e.printStackTrace();
	         }
	      }
	   }
	
	
	
	public static String trovaSucc(String a,String path) {
	    
	      FileInputStream fstream = null; 
	      DataInputStream in = null;
	    
	      try {
	         // apro il file
	         fstream = new FileInputStream(path);
	     
	         // prendo l'inputStream
	         in = new DataInputStream(fstream);
	         BufferedReader br = new BufferedReader(new InputStreamReader(in));
	         String strline;
	     
	         // Leggo il file riga per riga
	         boolean ok=false;
	         while ((strline = br.readLine()) != null) {
	        	boolean tro=true;
	        	int i=0;
	        	while(i<a.length()&&tro) {
	        		if(strline.charAt(i)!=a.charAt(i)) {
	        			tro=false;
	        		}
	        	i++;
	        	} 
	        	if(tro) {
	        		String s ="";
		        	 int j=a.length();
		        	 while(j<strline.length()) {
		        		 s=s+strline.charAt(j);
		        		 j++;
		        	 }	 
		        	 return s;
	        	}
	        		
	         }
	     
	      } catch (Exception e) {
	         e.printStackTrace();
	 
	      } finally {
	         // chiusura dell'output e dell'input
	         try {
	            fstream.close();
	            in.close();
	         } catch (IOException e) {
	            e.printStackTrace();
	         }
	      }
		return null;
	   }
	
	
	public static ArrayList<String> contenuto(String path) {
	    
	      FileInputStream fstream = null; 
	      DataInputStream in = null;

	      ArrayList<String> s=new ArrayList<String>();
	    
	      try {
	         // apro il file
	         fstream = new FileInputStream(path);
	     
	         // prendo l'inputStream
	         in = new DataInputStream(fstream);
	         BufferedReader br = new BufferedReader(new InputStreamReader(in));
	         String strline;
	         StringBuilder fileContent = new StringBuilder();
	     
	         // Leggo il file riga per riga
	         while ((strline = br.readLine()) != null) {
	        	 
	        	 s.add(strline);
	        	} 
	        	
	         return s;

	  
	     
	      } catch (Exception e) {
	         e.printStackTrace();
	 
	      }
		return null;
	   }
	
	
	}
