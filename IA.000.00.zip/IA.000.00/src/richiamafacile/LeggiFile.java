package richiamafacile;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LeggiFile {

	public static String posizionefile(String posizione) {
		StringBuilder costruisci=new StringBuilder();
		try {
			BufferedReader br=new BufferedReader(new InputStreamReader(LeggiFile.class.getResource(posizione).openStream()));
			String line;
			while((line=br.readLine())!=null) {
				costruisci.append(line +"\n");
			}
			br.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		return costruisci.toString();
	}
	
	
	public static String posizionefile2(String posizione) {
		FileInputStream fstream = null; 
	     DataInputStream in = null;
		StringBuilder costruisci=new StringBuilder();
		try {
			fstream = new FileInputStream(posizione);
	         in = new DataInputStream(fstream);
	         BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String line;
			while((line=br.readLine())!=null) {
				costruisci.append(line +"\n");
			}
			br.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		return costruisci.toString();
	}
	

	public static int parseInt(String num) {
		try {
			return Integer.parseInt(num);
		}catch(NumberFormatException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	
}
