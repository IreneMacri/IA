package disegnafacile;

import java.awt.Graphics;

import richiamafacile.Crea;

public class SpCurva4 extends Pezzo{

	public SpCurva4(int x, int y) {
		super(Crea.curva4,6,x,y);
		
	}

	

	@Override
	public void aggiorna() {
		// TODO Auto-generated method stub
		
	}

}
