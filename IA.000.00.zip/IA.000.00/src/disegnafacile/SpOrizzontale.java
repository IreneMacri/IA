package disegnafacile;

import richiamafacile.Crea;

public class SpOrizzontale extends Pezzo{

	public SpOrizzontale(int x, int y) {
		super(Crea.sporizzontale,2,x,y);
		
	}

	@Override
	public void aggiorna() {
		// TODO Auto-generated method stub
		
	}

}
