package disegnafacile;

import richiamafacile.Crea;

public class SpVerticale extends Pezzo{

	public SpVerticale(int x, int y) {
		super(Crea.spverticale,8,x,y);
		
	}

	@Override
	public void aggiorna() {
		// TODO Auto-generated method stub
		
	}


}
