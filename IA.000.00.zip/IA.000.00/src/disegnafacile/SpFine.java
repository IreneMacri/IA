package disegnafacile;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import richiamafacile.Crea;

public class SpFine extends Pezzo{


	private double radianti;
	private double ruota;
	protected int decimi;
	
	public SpFine(int x, int y,double ruota) {
		super(null,7,x,y);
		this.ruota=ruota;
		this.decimi=0;
		
	}

	@Override
	public void aggiorna() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void disegna(Graphics gr) {
		Graphics2D g = (Graphics2D)gr;
        g.setRenderingHint(
            RenderingHints.KEY_RENDERING, 
            RenderingHints.VALUE_RENDER_QUALITY);

        AffineTransform oldAT = g.getTransform();
        float x0,y0;
        radianti = Math.toRadians(ruota);
        x0=(x*larghezza-larghezza/2)+larghezza;
        y0=(y*altezza+yy-altezza/2)+altezza;
        g.translate(x0, y0);
        g.rotate(radianti);
        g.translate(-(larghezza), -(altezza));
        g.drawImage(Crea.spfine[decimi], 0, 0,(int)larghezza*2,(int)altezza*2, null);
        g.setTransform(oldAT);
		//g.drawImage(img,(int)(x*larghezza-larghezza/2), (int)(y*altezza+yy-altezza/2), (int)(larghezza*2), (int)(altezza*2), null);
		
	}

	
	
//***************************************************SET**********************************
	
	public void setDecimi(int a) {

		this.decimi=a;
		
	}
	
	
	
}