package disegnafacile;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import richiamafacile.Crea;

public abstract class Pezzo {
	
	public static final int larghezza_default=32, altezza_default=32;
	protected BufferedImage img;
	protected final int id;
	protected int valore;
	protected float x,y,yy;
	protected float larghezza,altezza;
	
	public Pezzo(BufferedImage img, int id,int x,int y) {
		this.larghezza=Crea.convertiMisuraLargh(larghezza_default);
		this.altezza=Crea.convertiMisuraAlt(altezza_default);
		this.yy=Crea.convertiMisuraAlt(48);
		this.img=img;
		this.id=id;
		this.x=x;
		this.y=y;
	}

	public abstract void aggiorna() ;
	
	
	public void disegna(Graphics g) {
		g.drawImage(img,(int)(x*larghezza), (int)(y*altezza+yy), (int)(larghezza), (int)(altezza), null);
	}
	
//***************GET********************
	
	public int getId() {
		return id;
	}
	
	
	public float getX() {
		return x;
	}

	
	public float getY() {
		return y;
	}
	
	public int getValore() {
		return valore;
	}
	
	
	public float getAltezza() {
		return altezza;
	}
	
	public float getLarghezza() {
		return larghezza;
	}

		
	
//*******************************SET*****************************************

	
	public void setValore(int valore) {
		this.valore = valore;
	}

	public void setDecimi(int a) {
		
		// TODO Auto-generated method stub
		
	}

	
	
	
}
