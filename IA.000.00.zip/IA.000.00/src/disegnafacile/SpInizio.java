package disegnafacile;

import richiamafacile.Crea;

public class SpInizio extends Pezzo{

	public SpInizio(int x, int y) {
		super(Crea.spinizio,1,x,y);
		
	}

	@Override
	public void aggiorna() {
		// TODO Auto-generated method stub
		
	}

}
