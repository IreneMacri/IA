package disegnafacile;

import richiamafacile.Crea;

public class SpCurva2 extends Pezzo{

	public SpCurva2(int x, int y) {
		super(Crea.curva2,4,x,y);
		
	}

	@Override
	public void aggiorna() {
		// TODO Auto-generated method stub
		
	}

}
