package disegnafacile;

import richiamafacile.Crea;

public class SpCurva3 extends Pezzo{

	public SpCurva3(int x, int y) {
		super(Crea.curva3,5,x,y);
		
	}

	@Override
	public void aggiorna() {
		// TODO Auto-generated method stub
		
	}

}
