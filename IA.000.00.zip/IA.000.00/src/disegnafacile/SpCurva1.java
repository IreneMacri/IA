package disegnafacile;

import richiamafacile.Crea;

public class SpCurva1 extends Pezzo{

	public SpCurva1(int x, int y) {
		super(Crea.curva1,3,x,y);
		
	}

	@Override
	public void aggiorna() {
		// TODO Auto-generated method stub
		
	}

}
